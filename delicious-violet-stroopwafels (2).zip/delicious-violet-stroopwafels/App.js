import React, { useState, useEffect, useCallback } from 'react';
import {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableOpacity,
  SafeAreaView,
  ScrollView,
  StatusBar,
  Platform,
  Alert,
  ActivityIndicator,
  Dimensions,
  Modal,
  Image,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import DateTimePicker from '@react-native-community/datetimepicker';
import * as ImagePicker from 'expo-image-picker';

const { width: SCREEN_WIDTH } = Dimensions.get('window');

export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [loading, setLoading] = useState(true);

  // Auth States
  const [authMode, setAuthMode] = useState('login');
  const [fullName, setFullName] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  // Main App State
  const [pets, setPets] = useState([]);
  const [selectedPet, setSelectedPet] = useState(null);
  const [activeTab, setActiveTab] = useState('vet'); 
  const [selectedRange, setSelectedRange] = useState('Tümü');

  // Modal / Form States
  const [showAddPet, setShowAddPet] = useState(false);
  const [newPetName, setNewPetName] = useState('');
  const [newPetType, setNewPetType] = useState('Kedi');
  const [newPetAge, setNewPetAge] = useState('');
  const [newPetBreed, setNewPetBreed] = useState('');
  const [newPetImageUri, setNewPetImageUri] = useState(null);

  // Form States inside Pet Details
  const [vetClinic, setVetClinic] = useState('');
  const [vetDoctor, setVetDoctor] = useState('');
  const [vetReason, setVetReason] = useState('');
  const [vetDate, setVetDate] = useState('');

  const [vacName, setVacName] = useState('');
  const [vacType, setVacType] = useState('Parazit Uygulamaları');
  const [vacDate, setVacDate] = useState('');
  const [vacPrice, setVacPrice] = useState('');

  const [weightValue, setWeightValue] = useState('');
  const [weightDate, setWeightDate] = useState('');

  const [foodTitle, setFoodTitle] = useState('');
  const [foodAmount, setFoodAmount] = useState('');
  const [foodPrice, setFoodPrice] = useState('');

  // Date Picker States
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [pickerTarget, setPickerTarget] = useState(null); // 'vet', 'vac', 'weight'
  const [selectedDateObj, setSelectedDateObj] = useState(new Date());

  const loadAppData = useCallback(async () => {
    try {
      const storedPets = await AsyncStorage.getItem('@pets_v3_data');
      if (storedPets) {
        setPets(JSON.parse(storedPets));
      } else {
        const defaultPets = [
          {
            id: '1',
            name: 'Gümüş',
            type: 'Kedi',
            breed: 'Scottish Shorthair',
            age: '2 Yaşında',
            imageUri: null,
            vets: [
              {
                id: 'v1',
                clinic: 'Pati Merkez Veteriner Klinik',
                doctor: 'Dr. Ahmet Yılmaz',
                reason: 'Rutin Genel Kontrol & Tırnak Kesimi',
                date: '10.09.2026',
              },
            ],
            vaccines: [
              { id: 'vc1', name: 'İç/Dış Parazit Damlası', type: 'Parazit Uygulamaları', date: '12.08.2026', price: '300' },
              { id: 'vc2', name: 'Karma Aşı', type: 'Aşı', date: '10.05.2026', price: '450' },
            ],
            weights: [
              { id: 'w1', weight: '4.8', date: '20 Haz' },
              { id: 'w2', weight: '4.7', date: '27 Haz' },
              { id: 'w3', weight: '4.5', date: '01 Tem' },
              { id: 'w4', weight: '4.4', date: '05 Tem' },
              { id: 'w5', weight: '4.2', date: '09 Tem' },
              { id: 'w6', weight: '4.1', date: '13 Tem' },
            ],
            foods: [
              { id: 'f1', title: 'Premium Kedi Maması', amount: '10', price: '1200', unitPrice: '120' },
            ],
          },
        ];
        setPets(defaultPets);
        await AsyncStorage.setItem('@pets_v3_data', JSON.stringify(defaultPets));
      }
    } catch (e) {
      console.error('Veri yükleme hatası:', e);
    }
  }, []);

  const loadInitialData = useCallback(async () => {
    try {
      const authStatus = await AsyncStorage.getItem('@is_logged_in');
      if (authStatus === 'true') {
        setIsLoggedIn(true);
        const storedUser = await AsyncStorage.getItem('@user_fullname');
        if (storedUser) setFullName(storedUser);
        await loadAppData();
      }
    } catch (e) {
      console.error('Hata:', e);
    } finally {
      setLoading(false);
    }
  }, [loadAppData]);

  useEffect(() => {
    loadInitialData();
  }, [loadInitialData]);

  const savePetsToStorage = async (updatedPets) => {
    setPets(updatedPets);
    await AsyncStorage.setItem('@pets_v3_data', JSON.stringify(updatedPets));
    if (selectedPet) {
      const current = updatedPets.find((p) => p.id === selectedPet.id);
      if (current) setSelectedPet(current);
    }
  };

  // Image Picker Function
  const pickImage = async (onImagePicked) => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('İzin Gerekli', 'Fotoğraf seçebilmek için galeri erişim izni vermeniz gerekmektedir.');
      return;
    }

    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.8,
    });

    if (!result.canceled && result.assets && result.assets.length > 0) {
      onImagePicked(result.assets[0].uri);
    }
  };

  // Date Formatting Helper
  const formatDate = (date, mode = 'full') => {
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();

    if (mode === 'short') {
      const monthNames = ['Oca', 'Şub', 'Mar', 'Nis', 'May', 'Haz', 'Tem', 'Ağu', 'Eyl', 'Eki', 'Kas', 'Ara'];
      return `${day} ${monthNames[date.getMonth()]}`;
    }

    return `${day}.${month}.${year}`;
  };

  const handleOpenDatePicker = (target) => {
    setPickerTarget(target);
    setShowDatePicker(true);
  };

  const handleDateChange = (event, selectedDate) => {
    if (Platform.OS === 'android') {
      setShowDatePicker(false);
    }

    if (selectedDate) {
      setSelectedDateObj(selectedDate);
      if (pickerTarget === 'vet') {
        setVetDate(formatDate(selectedDate, 'full'));
      } else if (pickerTarget === 'vac') {
        setVacDate(formatDate(selectedDate, 'full'));
      } else if (pickerTarget === 'weight') {
        setWeightDate(formatDate(selectedDate, 'short'));
      }
    }
  };

  const handleLogin = async () => {
    if (!username.trim() || !password.trim()) {
      Alert.alert('Eksik Bilgi', 'Lütfen kullanıcı adı ve şifrenizi giriniz.');
      return;
    }
    const savedUser = await AsyncStorage.getItem(`@user_${username.trim().toLowerCase()}`);
    if (savedUser) {
      const userData = JSON.parse(savedUser);
      if (userData.password === password) {
        await AsyncStorage.setItem('@is_logged_in', 'true');
        await AsyncStorage.setItem('@user_fullname', userData.fullName || username);
        setFullName(userData.fullName || username);
        setIsLoggedIn(true);
        await loadAppData();
        return;
      }
    }
    if (username.trim().toLowerCase() === 'halil' && password === '1234') {
      await AsyncStorage.setItem('@is_logged_in', 'true');
      await AsyncStorage.setItem('@user_fullname', 'Halil');
      setFullName('Halil');
      setIsLoggedIn(true);
      await loadAppData();
    } else {
      Alert.alert('Hata', 'Kullanıcı adı veya şifre hatalı.');
    }
  };

  const handleRegister = async () => {
    if (!fullName.trim() || !username.trim() || !password.trim()) {
      Alert.alert('Eksik Bilgi', 'Lütfen tüm alanları doldurunuz.');
      return;
    }
    const userData = {
      fullName: fullName.trim(),
      username: username.trim().toLowerCase(),
      password: password,
    };
    await AsyncStorage.setItem(`@user_${userData.username}`, JSON.stringify(userData));
    await AsyncStorage.setItem('@is_logged_in', 'true');
    await AsyncStorage.setItem('@user_fullname', userData.fullName);
    Alert.alert('Başarılı', 'Hesabınız oluşturuldu!');
    setIsLoggedIn(true);
    await loadAppData();
  };

  const handleLogout = async () => {
    await AsyncStorage.setItem('@is_logged_in', 'false');
    setIsLoggedIn(false);
    setSelectedPet(null);
  };

  const handleAddPet = async () => {
    if (!newPetName.trim()) {
      Alert.alert('Hata', 'Lütfen evcil hayvan ismini girin.');
      return;
    }
    const newPet = {
      id: Date.now().toString(),
      name: newPetName.trim(),
      type: newPetType,
      breed: newPetBreed.trim() || 'Irk Belirtilmedi',
      age: newPetAge.trim() ? `${newPetAge.trim()} Yaşında` : 'Yaş Belirtilmedi',
      imageUri: newPetImageUri,
      vets: [],
      vaccines: [],
      weights: [],
      foods: [],
    };
    const updated = [...pets, newPet];
    await savePetsToStorage(updated);
    setNewPetName('');
    setNewPetAge('');
    setNewPetBreed('');
    setNewPetImageUri(null);
    setShowAddPet(false);
  };

  const handleUpdatePetImage = async (petId, newUri) => {
    const updatedPets = pets.map((p) => {
      if (p.id === petId) {
        return { ...p, imageUri: newUri };
      }
      return p;
    });
    await savePetsToStorage(updatedPets);
  };

  const handleAddVet = async () => {
    if (!vetClinic.trim() || !vetReason.trim() || !vetDate.trim()) {
      Alert.alert('Hata', 'Lütfen Klinik Adı, Muayene Nedeni ve Tarih alanlarını doldurun.');
      return;
    }
    const newItem = {
      id: Date.now().toString(),
      clinic: vetClinic.trim(),
      doctor: vetDoctor.trim() || 'Belirtilmedi',
      reason: vetReason.trim(),
      date: vetDate.trim(),
    };
    const updatedPets = pets.map((p) => {
      if (p.id === selectedPet.id) {
        return { ...p, vets: [newItem, ...(p.vets || [])] };
      }
      return p;
    });
    await savePetsToStorage(updatedPets);
    setVetClinic('');
    setVetDoctor('');
    setVetReason('');
    setVetDate('');
  };

  const handleAddVaccine = async () => {
    if (!vacName.trim() || !vacDate.trim()) {
      Alert.alert('Hata', 'Lütfen uygulama adı ve tarih girin.');
      return;
    }
    const newItem = {
      id: Date.now().toString(),
      name: vacName.trim(),
      type: vacType,
      date: vacDate.trim(),
      price: vacPrice.trim() || '0',
    };
    const updatedPets = pets.map((p) => {
      if (p.id === selectedPet.id) {
        return { ...p, vaccines: [newItem, ...(p.vaccines || [])] };
      }
      return p;
    });
    await savePetsToStorage(updatedPets);
    setVacName('');
    setVacDate('');
    setVacPrice('');
  };

  const handleAddWeight = async () => {
    if (!weightValue.trim() || !weightDate.trim()) {
      Alert.alert('Hata', 'Lütfen kilo ve tarih değerlerini girin.');
      return;
    }
    const newItem = {
      id: Date.now().toString(),
      weight: weightValue.trim(),
      date: weightDate.trim(),
    };
    const updatedPets = pets.map((p) => {
      if (p.id === selectedPet.id) {
        return { ...p, weights: [...(p.weights || []), newItem] };
      }
      return p;
    });
    await savePetsToStorage(updatedPets);
    setWeightValue('');
    setWeightDate('');
  };

  const handleAddFood = async () => {
    if (!foodTitle.trim() || !foodAmount.trim() || !foodPrice.trim()) {
      Alert.alert('Hata', 'Lütfen tüm alanları doldurun.');
      return;
    }
    const amountNum = parseFloat(foodAmount);
    const priceNum = parseFloat(foodPrice);
    const unit = amountNum > 0 ? (priceNum / amountNum).toFixed(1) : '0';

    const newItem = {
      id: Date.now().toString(),
      title: foodTitle.trim(),
      amount: foodAmount.trim(),
      price: foodPrice.trim(),
      unitPrice: unit,
    };
    const updatedPets = pets.map((p) => {
      if (p.id === selectedPet.id) {
        return { ...p, foods: [newItem, ...(p.foods || [])] };
      }
      return p;
    });
    await savePetsToStorage(updatedPets);
    setFoodTitle('');
    setFoodAmount('');
    setFoodPrice('');
  };

  const getPetIcon = (type) => {
    switch (type) {
      case 'Köpek': return '🐶';
      case 'Kuş': return '🦜';
      case 'Kedi': default: return '🐱';
    }
  };

  // KİLO GRAFİĞİ BİLEŞENİ
  const renderImageMatchedWeightChart = (pet) => {
    const data = pet.weights || [];
    if (data.length === 0) {
      return (
        <View style={styles.imageChartCard}>
          <Text style={styles.chartTitleText}>Kilo Takibi</Text>
          <View style={{ paddingVertical: 20, alignItems: 'center' }}>
            <Text style={{ color: '#A8A29E', fontSize: 13 }}>Henüz kilo kaydı eklenmemiş.</Text>
          </View>
        </View>
      );
    }

    const weights = data.map((d) => parseFloat(d.weight) || 0);
    const lastWeight = weights[weights.length - 1] || 0;
    const firstWeight = weights[0] || 0;
    const diff = (lastWeight - firstWeight).toFixed(1);
    const diffText = diff <= 0 ? `${diff} kg` : `+${diff} kg`;

    const minWeight = Math.floor(Math.min(...weights)) - 1;
    const maxWeight = Math.ceil(Math.max(...weights)) + 1;
    const step = ((maxWeight - minWeight) / 4).toFixed(1);

    const yGridLabels = [
      maxWeight,
      (maxWeight - parseFloat(step)).toFixed(1),
      (maxWeight - parseFloat(step) * 2).toFixed(1),
      (maxWeight - parseFloat(step) * 3).toFixed(1),
      minWeight,
    ];

    const fluXValues = [-0.1, 0.2, -0.3, 0.15, -0.2, 0.05];

    return (
      <View style={styles.imageChartCard}>
        <View style={styles.chartHeaderRow}>
          <View>
            <Text style={styles.chartMainValText}>{lastWeight} kg</Text>
            <Text style={styles.chartSubDateText}>
              {data[0]?.date || ''} - {data[data.length - 1]?.date || ''}
            </Text>
          </View>
          <Text style={styles.chartDiffBadgeText}>{diffText}</Text>
        </View>

        <View style={styles.chartBodyWrapper}>
          <View style={styles.yAxisOverlay}>
            {yGridLabels.map((val, idx) => (
              <View key={idx} style={styles.yGridRow}>
                <View style={styles.dashedLineItem} />
                <Text style={styles.yGridLabelText}>{val}</Text>
              </View>
            ))}
          </View>

          <View style={styles.chartDataPointsArea}>
            {data.map((item, index) => {
              const val = parseFloat(item.weight) || 0;
              const pct = Math.max(0, Math.min(100, ((val - minWeight) / (maxWeight - minWeight)) * 100));

              const fluVal = fluXValues[index % fluXValues.length] || 0;
              const fluPct = Math.max(0, Math.min(100, pct + fluVal * 25));

              return (
                <View key={item.id || index} style={styles.pointColumnItem}>
                  <View style={[styles.fluctuateDot, { bottom: `${fluPct}%` }]} />
                  <View style={[styles.mainTrendDot, { bottom: `${pct}%` }]}>
                    <View style={styles.innerDotHole} />
                  </View>
                </View>
              );
            })}
          </View>

          <View style={styles.xAxisLabelsRow}>
            {data.map((item, idx) => (
              <Text key={idx} style={styles.xDateText}>{item.date}</Text>
            ))}
          </View>
        </View>

        <View style={styles.timeFilterRow}>
          {['1H', '1A', '3A', '6A', '1Y', 'Tümü'].map((range) => (
            <TouchableOpacity
              key={range}
              style={[
                styles.filterBtn,
                selectedRange === range && styles.filterBtnActive,
              ]}
              onPress={() => setSelectedRange(range)}
            >
              <Text
                style={[
                  styles.filterBtnText,
                  selectedRange === range && styles.filterBtnTextActive,
                ]}
              >
                {range}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>
    );
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#EA580C" />
      </View>
    );
  }

  // GİRİŞ / KAYIT OL EKRANI
  if (!isLoggedIn) {
    return (
      <SafeAreaView style={styles.safeArea}>
        <StatusBar barStyle="dark-content" />
        <ScrollView contentContainerStyle={styles.authContainer} showsVerticalScrollIndicator={false}>
          <View style={styles.authHeader}>
            <Text style={styles.authEmoji}>🐾</Text>
            <Text style={styles.appTitle}>PawLog</Text>
            <Text style={styles.appSubtitle}>Smart Pet Care Tracker</Text>
          </View>

          <View style={styles.card}>
            <View style={styles.authTabSwitch}>
              <TouchableOpacity
                style={[styles.authTabBtn, authMode === 'login' && styles.authTabBtnActive]}
                onPress={() => setAuthMode('login')}
              >
                <Text style={[styles.authTabBtnText, authMode === 'login' && styles.authTabBtnTextActive]}>
                  Giriş Yap
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.authTabBtn, authMode === 'register' && styles.authTabBtnActive]}
                onPress={() => setAuthMode('register')}
              >
                <Text style={[styles.authTabBtnText, authMode === 'register' && styles.authTabBtnTextActive]}>
                  Kayıt Ol
                </Text>
              </TouchableOpacity>
            </View>

            {authMode === 'register' && (
              <TextInput
                style={styles.input}
                placeholder="Adınız Soyadınız"
                placeholderTextColor="#A8A29E"
                value={fullName}
                onChangeText={setFullName}
              />
            )}

            <TextInput
              style={styles.input}
              placeholder="Kullanıcı Adı"
              placeholderTextColor="#A8A29E"
              value={username}
              onChangeText={setUsername}
              autoCapitalize="none"
            />
            <TextInput
              style={styles.input}
              placeholder="Şifre"
              placeholderTextColor="#A8A29E"
              value={password}
              onChangeText={setPassword}
              secureTextEntry
            />

            {authMode === 'login' ? (
              <TouchableOpacity style={styles.btnPrimary} onPress={handleLogin}>
                <Text style={styles.btnPrimaryText}>Giriş Yap</Text>
              </TouchableOpacity>
            ) : (
              <TouchableOpacity style={styles.btnPrimary} onPress={handleRegister}>
                <Text style={styles.btnPrimaryText}>Hesap Oluştur ve Başla</Text>
              </TouchableOpacity>
            )}
          </View>
        </ScrollView>
      </SafeAreaView>
    );
  }

  // EVCİL HAYVAN DETAY EKRANI
  if (selectedPet) {
    return (
      <SafeAreaView style={styles.safeArea}>
        <StatusBar barStyle="dark-content" />
        <View style={styles.container}>
          <View style={styles.topNav}>
            <TouchableOpacity style={styles.btnBack} onPress={() => setSelectedPet(null)}>
              <Text style={styles.btnBackText}>‹ Tüm Dostlar</Text>
            </TouchableOpacity>
            <Text style={styles.topNavTitle}>{selectedPet.name}</Text>
            <View style={{ width: 80 }} />
          </View>

          <View style={styles.petHeaderCard}>
            <TouchableOpacity onPress={() => pickImage((uri) => handleUpdatePetImage(selectedPet.id, uri))}>
              {selectedPet.imageUri ? (
                <Image source={{ uri: selectedPet.imageUri }} style={styles.petHeaderAvatarImage} />
              ) : (
                <Text style={styles.petHeaderAvatar}>{getPetIcon(selectedPet.type)}</Text>
              )}
            </TouchableOpacity>
            <View style={{ flex: 1, marginLeft: 12 }}>
              <Text style={styles.petHeaderName}>{selectedPet.name}</Text>
              <Text style={styles.petHeaderSub}>
                {selectedPet.breed} • {selectedPet.age}
              </Text>
              <Text style={styles.changePhotoHintText}>📷 Fotoğrafı Değiştir</Text>
            </View>
          </View>

          {/* SEKMELER */}
          <View style={styles.tabBarContainer}>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.tabBarContent}>
              <TouchableOpacity
                style={[styles.tabItem, activeTab === 'vet' && styles.tabItemActive]}
                onPress={() => setActiveTab('vet')}
              >
                <Text style={[styles.tabItemText, activeTab === 'vet' && styles.tabItemTextActive]}>
                  🏥 Veteriner
                </Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={[styles.tabItem, activeTab === 'parasite' && styles.tabItemActive]}
                onPress={() => setActiveTab('parasite')}
              >
                <Text style={[styles.tabItemText, activeTab === 'parasite' && styles.tabItemTextActive]}>
                  🪱 Parazit Uygulamaları
                </Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={[styles.tabItem, activeTab === 'vaccines' && styles.tabItemActive]}
                onPress={() => setActiveTab('vaccines')}
              >
                <Text style={[styles.tabItemText, activeTab === 'vaccines' && styles.tabItemTextActive]}>
                  💉 Aşılar
                </Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={[styles.tabItem, activeTab === 'weight' && styles.tabItemActive]}
                onPress={() => setActiveTab('weight')}
              >
                <Text style={[styles.tabItemText, activeTab === 'weight' && styles.tabItemTextActive]}>
                  ⚖ Kilo Takibi
                </Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={[styles.tabItem, activeTab === 'food' && styles.tabItemActive]}
                onPress={() => setActiveTab('food')}
              >
                <Text style={[styles.tabItemText, activeTab === 'food' && styles.tabItemTextActive]}>
                  🍲 Mama
                </Text>
              </TouchableOpacity>
            </ScrollView>
          </View>

          <ScrollView style={{ flex: 1, paddingHorizontal: 16 }} showsVerticalScrollIndicator={false}>
            {/* 1. SEKME: VETERİNER */}
            {activeTab === 'vet' && (
              <>
                <View style={styles.card}>
                  <Text style={styles.cardTitle}>+ Yeni Veteriner Ziyareti Ekle</Text>
                  <TextInput
                    style={styles.input}
                    placeholder="Klinik Adı (örn. Pati Veteriner Kliniği)"
                    placeholderTextColor="#A8A29E"
                    value={vetClinic}
                    onChangeText={setVetClinic}
                  />
                  <TextInput
                    style={styles.input}
                    placeholder="Hekim / Doktor Adı (örn. Dr. Ahmet)"
                    placeholderTextColor="#A8A29E"
                    value={vetDoctor}
                    onChangeText={setVetDoctor}
                  />
                  <TextInput
                    style={styles.input}
                    placeholder="Şikayet / Muayene Nedeni"
                    placeholderTextColor="#A8A29E"
                    value={vetReason}
                    onChangeText={setVetReason}
                  />

                  {/* Tarih Seçici Butonu */}
                  <TouchableOpacity
                    style={styles.datePickerInputBtn}
                    onPress={() => handleOpenDatePicker('vet')}
                  >
                    <Text style={vetDate ? styles.datePickerTextActive : styles.datePickerTextPlaceholder}>
                      {vetDate ? `📅 ${vetDate}` : '📅 Tarih Ekle (Takvimden Seç)'}
                    </Text>
                  </TouchableOpacity>

                  <TouchableOpacity style={styles.btnPrimary} onPress={handleAddVet}>
                    <Text style={styles.btnPrimaryText}>Veteriner Kaydını Ekle</Text>
                  </TouchableOpacity>
                </View>

                <View style={styles.card}>
                  <Text style={styles.cardTitle}>Geçmiş Veteriner Ziyaretleri</Text>
                  {!selectedPet.vets || selectedPet.vets.length === 0 ? (
                    <Text style={styles.emptyText}>Henüz veteriner ziyareti eklenmemiş.</Text>
                  ) : (
                    selectedPet.vets.map((v) => (
                      <View key={v.id} style={styles.vetCardItem}>
                        <View style={styles.vetTopDateBadge}>
                          <Text style={styles.vetDateText}>📅 {v.date}</Text>
                        </View>
                        <Text style={styles.vetClinicText}>🏥 {v.clinic}</Text>
                        <Text style={styles.vetDoctorText}>👨‍⚕️ Hekim: {v.doctor}</Text>
                        <View style={styles.vetReasonBox}>
                          <Text style={styles.vetReasonLabel}>Şikayet / Neden:</Text>
                          <Text style={styles.vetReasonText}>{v.reason}</Text>
                        </View>
                      </View>
                    ))
                  )}
                </View>
              </>
            )}

            {/* 2. SEKME: PARAZİT */}
            {activeTab === 'parasite' && (
              <>
                <View style={styles.card}>
                  <Text style={styles.cardTitle}>+ Parazit Uygulaması Kaydı Ekle</Text>
                  <TextInput
                    style={styles.input}
                    placeholder="Uygulama Adı (örn. İç/Dış Parazit Damlası)"
                    placeholderTextColor="#A8A29E"
                    value={vacName}
                    onChangeText={setVacName}
                  />
                  <View style={{ flexDirection: 'row', gap: 8 }}>
                    <TouchableOpacity
                      style={[styles.datePickerInputBtn, { flex: 1 }]}
                      onPress={() => handleOpenDatePicker('vac')}
                    >
                      <Text style={vacDate ? styles.datePickerTextActive : styles.datePickerTextPlaceholder}>
                        {vacDate ? `📅 ${vacDate}` : '📅 Tarih Ekle'}
                      </Text>
                    </TouchableOpacity>

                    <TextInput
                      style={[styles.input, { flex: 1 }]}
                      placeholder="Ücret (₺)"
                      placeholderTextColor="#A8A29E"
                      keyboardType="numeric"
                      value={vacPrice}
                      onChangeText={setVacPrice}
                    />
                  </View>
                  <TouchableOpacity style={styles.btnPrimary} onPress={() => { setVacType('Parazit Uygulamaları'); handleAddVaccine(); }}>
                    <Text style={styles.btnPrimaryText}>Parazit Kaydını Ekle</Text>
                  </TouchableOpacity>
                </View>

                <View style={styles.card}>
                  <Text style={styles.cardTitle}>Parazit Uygulama Geçmişi</Text>
                  {selectedPet.vaccines?.filter((v) => v.type === 'Parazit Uygulamaları').length === 0 ? (
                    <Text style={styles.emptyText}>Henüz parazit kaydı yok.</Text>
                  ) : (
                    selectedPet.vaccines
                      ?.filter((v) => v.type === 'Parazit Uygulamaları')
                      .map((v) => (
                        <View key={v.id} style={styles.listItem}>
                          <View>
                            <Text style={styles.listItemTitle}>{v.name}</Text>
                            <Text style={styles.listItemSub}>Tarih: {v.date}</Text>
                          </View>
                          <Text style={styles.priceText}>{v.price} ₺</Text>
                        </View>
                      ))
                  )}
                </View>
              </>
            )}

            {/* 3. SEKME: AŞILAR */}
            {activeTab === 'vaccines' && (
              <>
                <View style={styles.card}>
                  <Text style={styles.cardTitle}>+ Aşı Kaydı Ekle</Text>
                  <TextInput
                    style={styles.input}
                    placeholder="Aşı Adı (örn. Karma Aşı, Kuduz)"
                    placeholderTextColor="#A8A29E"
                    value={vacName}
                    onChangeText={setVacName}
                  />
                  <View style={{ flexDirection: 'row', gap: 8 }}>
                    <TouchableOpacity
                      style={[styles.datePickerInputBtn, { flex: 1 }]}
                      onPress={() => handleOpenDatePicker('vac')}
                    >
                      <Text style={vacDate ? styles.datePickerTextActive : styles.datePickerTextPlaceholder}>
                        {vacDate ? `📅 ${vacDate}` : '📅 Tarih Ekle'}
                      </Text>
                    </TouchableOpacity>

                    <TextInput
                      style={[styles.input, { flex: 1 }]}
                      placeholder="Ücret (₺)"
                      placeholderTextColor="#A8A29E"
                      keyboardType="numeric"
                      value={vacPrice}
                      onChangeText={setVacPrice}
                    />
                  </View>
                  <TouchableOpacity style={styles.btnPrimary} onPress={() => { setVacType('Aşı'); handleAddVaccine(); }}>
                    <Text style={styles.btnPrimaryText}>Aşı Kaydını Ekle</Text>
                  </TouchableOpacity>
                </View>

                <View style={styles.card}>
                  <Text style={styles.cardTitle}>Aşı Geçmişi</Text>
                  {selectedPet.vaccines?.filter((v) => v.type === 'Aşı').length === 0 ? (
                    <Text style={styles.emptyText}>Henüz aşı kaydı yok.</Text>
                  ) : (
                    selectedPet.vaccines
                      ?.filter((v) => v.type === 'Aşı')
                      .map((v) => (
                        <View key={v.id} style={styles.listItem}>
                          <View>
                            <Text style={styles.listItemTitle}>{v.name}</Text>
                            <Text style={styles.listItemSub}>Tarih: {v.date}</Text>
                          </View>
                          <Text style={styles.priceText}>{v.price} ₺</Text>
                        </View>
                      ))
                  )}
                </View>
              </>
            )}

            {/* 4. SEKME: KİLO TAKİBİ */}
            {activeTab === 'weight' && (
              <>
                {renderImageMatchedWeightChart(selectedPet)}

                <View style={styles.card}>
                  <Text style={styles.cardTitle}>+ Kilo Kaydı Ekle</Text>
                  <View style={{ flexDirection: 'row', gap: 8 }}>
                    <TextInput
                      style={[styles.input, { flex: 1 }]}
                      placeholder="Ağırlık (kg)"
                      placeholderTextColor="#A8A29E"
                      keyboardType="numeric"
                      value={weightValue}
                      onChangeText={setWeightValue}
                    />
                    
                    <TouchableOpacity
                      style={[styles.datePickerInputBtn, { flex: 1 }]}
                      onPress={() => handleOpenDatePicker('weight')}
                    >
                      <Text style={weightDate ? styles.datePickerTextActive : styles.datePickerTextPlaceholder}>
                        {weightDate ? `📅 ${weightDate}` : '📅 Tarih Ekle'}
                      </Text>
                    </TouchableOpacity>
                  </View>
                  <TouchableOpacity style={styles.btnPrimary} onPress={handleAddWeight}>
                    <Text style={styles.btnPrimaryText}>Kilo Kaydet</Text>
                  </TouchableOpacity>
                </View>
              </>
            )}

            {/* 5. SEKME: MAMA */}
            {activeTab === 'food' && (
              <>
                <View style={styles.card}>
                  <Text style={styles.cardTitle}>+ Mama Harcaması / Alımı Ekle</Text>
                  <TextInput
                    style={styles.input}
                    placeholder="Mama Adı (örn. Royal Canin 10kg)"
                    placeholderTextColor="#A8A29E"
                    value={foodTitle}
                    onChangeText={setFoodTitle}
                  />
                  <View style={{ flexDirection: 'row', gap: 8 }}>
                    <TextInput
                      style={[styles.input, { flex: 1 }]}
                      placeholder="Miktar (kg)"
                      placeholderTextColor="#A8A29E"
                      keyboardType="numeric"
                      value={foodAmount}
                      onChangeText={setFoodAmount}
                    />
                    <TextInput
                      style={[styles.input, { flex: 1 }]}
                      placeholder="Toplam Fiyat (₺)"
                      placeholderTextColor="#A8A29E"
                      keyboardType="numeric"
                      value={foodPrice}
                      onChangeText={setFoodPrice}
                    />
                  </View>
                  <TouchableOpacity style={styles.btnPrimary} onPress={handleAddFood}>
                    <Text style={styles.btnPrimaryText}>Mama Kaydını Ekle</Text>
                  </TouchableOpacity>
                </View>

                <View style={styles.card}>
                  <Text style={styles.cardTitle}>Mama Alım Geçmişi</Text>
                  {selectedPet.foods?.length === 0 ? (
                    <Text style={styles.emptyText}>Mama kaydı bulunmuyor.</Text>
                  ) : (
                    selectedPet.foods.map((f) => (
                      <View key={f.id} style={styles.listItem}>
                        <View>
                          <Text style={styles.listItemTitle}>{f.title}</Text>
                          <Text style={styles.listItemSub}>
                            {f.amount} kg • Birim: {f.unitPrice} ₺/kg
                          </Text>
                        </View>
                        <Text style={styles.priceText}>{f.price} ₺</Text>
                      </View>
                    ))
                  )}
                </View>
              </>
            )}
          </ScrollView>
        </View>

        {/* TAKVİM POPUP / MODAL (IOS & ANDROID UYUMLU) */}
        {showDatePicker && (
          Platform.OS === 'ios' ? (
            <Modal transparent animationType="fade" visible={showDatePicker}>
              <View style={styles.datePickerModalOverlay}>
                <View style={styles.datePickerModalContainer}>
                  <Text style={styles.datePickerModalTitle}>Tarih Seçin</Text>
                  <DateTimePicker
                    value={selectedDateObj}
                    mode="date"
                    display="spinner"
                    onChange={handleDateChange}
                    textColor="#1C1917"
                  />
                  <TouchableOpacity
                    style={styles.btnPrimary}
                    onPress={() => setShowDatePicker(false)}
                  >
                    <Text style={styles.btnPrimaryText}>Tamam</Text>
                  </TouchableOpacity>
                </View>
              </View>
            </Modal>
          ) : (
            <DateTimePicker
              value={selectedDateObj}
              mode="date"
              display="default"
              onChange={handleDateChange}
            />
          )
        )}
      </SafeAreaView>
    );
  }

  // ANA PANEL
  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar barStyle="dark-content" />
      <View style={styles.container}>
        <View style={styles.header}>
          <View>
            <Text style={styles.headerSubtitle}>Hoş Geldin, {fullName || 'Halil'}</Text>
            <Text style={styles.headerTitle}>PawLog 🐾</Text>
          </View>
        </View>

        <ScrollView style={{ flex: 1 }} showsVerticalScrollIndicator={false}>
          {showAddPet && (
            <View style={[styles.card, { marginHorizontal: 16 }]}>
              <Text style={styles.cardTitle}>Yeni Dost Ekle</Text>
              
              {/* Fotoğraf Seçim Alanı */}
              <TouchableOpacity
                style={styles.photoPickerContainer}
                onPress={() => pickImage(setNewPetImageUri)}
              >
                {newPetImageUri ? (
                  <Image source={{ uri: newPetImageUri }} style={styles.photoPickerImage} />
                ) : (
                  <View style={styles.photoPickerPlaceholder}>
                    <Text style={styles.photoPickerIcon}>📷</Text>
                    <Text style={styles.photoPickerText}>Fotoğraf Seç</Text>
                  </View>
                )}
              </TouchableOpacity>

              <TextInput
                style={styles.input}
                placeholder="İsim (örn. Gümüş, Limon)"
                placeholderTextColor="#A8A29E"
                value={newPetName}
                onChangeText={setNewPetName}
              />
              <View style={{ flexDirection: 'row', gap: 8, marginBottom: 10 }}>
                {['Kedi', 'Köpek', 'Kuş', 'Diğer'].map((t) => (
                  <TouchableOpacity
                    key={t}
                    style={[styles.chipSelect, newPetType === t && styles.chipSelectActive]}
                    onPress={() => setNewPetType(t)}
                  >
                    <Text style={[styles.chipSelectText, newPetType === t && styles.chipSelectTextActive]}>
                      {getPetIcon(t)} {t}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
              <View style={{ flexDirection: 'row', gap: 8 }}>
                <TextInput
                  style={[styles.input, { flex: 1 }]}
                  placeholder="Yaş"
                  placeholderTextColor="#A8A29E"
                  keyboardType="numeric"
                  value={newPetAge}
                  onChangeText={setNewPetAge}
                />
                <TextInput
                  style={[styles.input, { flex: 1 }]}
                  placeholder="Irk"
                  placeholderTextColor="#A8A29E"
                  value={newPetBreed}
                  onChangeText={setNewPetBreed}
                />
              </View>
              <View style={{ flexDirection: 'row', gap: 8, marginTop: 4 }}>
                <TouchableOpacity
                  style={[styles.btnPrimary, { flex: 1, backgroundColor: '#78716C' }]}
                  onPress={() => {
                    setShowAddPet(false);
                    setNewPetImageUri(null);
                  }}
                >
                  <Text style={styles.btnPrimaryText}>Vazgeç</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[styles.btnPrimary, { flex: 1 }]} onPress={handleAddPet}>
                  <Text style={styles.btnPrimaryText}>Kaydet</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}

          <View style={{ paddingHorizontal: 16, marginTop: 8 }}>
            <Text style={styles.sectionHeaderTitle}>Evcil Hayvanlarınız</Text>
            <View style={styles.gridContainer}>
              {pets.map((pet) => (
                <TouchableOpacity
                  key={pet.id}
                  style={styles.gridCard}
                  onPress={() => setSelectedPet(pet)}
                >
                  {pet.imageUri ? (
                    <Image source={{ uri: pet.imageUri }} style={styles.gridCardImage} />
                  ) : (
                    <Text style={styles.gridIcon}>{getPetIcon(pet.type)}</Text>
                  )}
                  <Text style={styles.gridPetName}>{pet.name}</Text>
                  <Text style={styles.gridPetAge}>{pet.age}</Text>
                  <Text style={styles.gridPetBreed}>{pet.breed}</Text>
                </TouchableOpacity>
              ))}

              <TouchableOpacity
                style={styles.addPetGridCard}
                onPress={() => setShowAddPet(!showAddPet)}
              >
                <Text style={styles.addPetGridIcon}>+</Text>
                <Text style={styles.addPetGridText}>Yeni Ekle</Text>
              </TouchableOpacity>
            </View>
          </View>

          <View style={styles.bottomLogoutContainer}>
            <TouchableOpacity onPress={handleLogout} style={styles.btnLogoutBottom}>
              <Text style={styles.btnLogoutBottomText}>Oturumu Kapat</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#FAF6F0',
    paddingTop: Platform.OS === 'android' ? StatusBar.currentHeight || 24 : 12,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#FAF6F0',
  },
  container: {
    flex: 1,
  },
  authContainer: {
    paddingVertical: 40,
    paddingHorizontal: 24,
  },
  authHeader: {
    alignItems: 'center',
    marginBottom: 24,
  },
  authEmoji: {
    fontSize: 54,
    marginBottom: 10,
  },
  appTitle: {
    fontSize: 28,
    fontWeight: '800',
    color: '#44403C',
  },
  appSubtitle: {
    fontSize: 14,
    color: '#78716C',
    marginTop: 4,
  },
  authTabSwitch: {
    flexDirection: 'row',
    backgroundColor: '#F5F5F4',
    borderRadius: 12,
    padding: 4,
    marginBottom: 16,
  },
  authTabBtn: {
    flex: 1,
    paddingVertical: 10,
    alignItems: 'center',
    borderRadius: 8,
  },
  authTabBtnActive: {
    backgroundColor: '#FFFFFF',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    elevation: 1,
  },
  authTabBtnText: {
    fontSize: 13,
    fontWeight: '600',
    color: '#78716C',
  },
  authTabBtnTextActive: {
    color: '#EA580C',
    fontWeight: '800',
  },

  header: {
    paddingHorizontal: 16,
    paddingTop: 12,
    paddingBottom: 12,
  },
  headerSubtitle: {
    fontSize: 12,
    fontWeight: '700',
    color: '#EA580C',
    textTransform: 'uppercase',
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: '800',
    color: '#292524',
  },

  // FOTOĞRAF SEÇİCİ STİLLERİ
  photoPickerContainer: {
    alignSelf: 'center',
    marginBottom: 14,
  },
  photoPickerPlaceholder: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#FAF6F0',
    borderWidth: 2,
    borderColor: '#EA580C',
    borderStyle: 'dashed',
    justifyContent: 'center',
    alignItems: 'center',
  },
  photoPickerIcon: {
    fontSize: 22,
  },
  photoPickerText: {
    fontSize: 10,
    fontWeight: '700',
    color: '#EA580C',
    marginTop: 2,
  },
  photoPickerImage: {
    width: 80,
    height: 80,
    borderRadius: 40,
    borderWidth: 2,
    borderColor: '#EA580C',
  },

  // DATE PICKER ÖZEL STİLLERİ
  datePickerInputBtn: {
    backgroundColor: '#FAF6F0',
    borderRadius: 12,
    padding: 12,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#E7E5E4',
    justifyContent: 'center',
  },
  datePickerTextPlaceholder: {
    fontSize: 13,
    color: '#A8A29E',
    fontWeight: '500',
  },
  datePickerTextActive: {
    fontSize: 13,
    color: '#EA580C',
    fontWeight: '700',
  },
  datePickerModalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.4)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  datePickerModalContainer: {
    width: '85%',
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    padding: 20,
    alignItems: 'center',
  },
  datePickerModalTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#292524',
    marginBottom: 10,
  },

  // BEYAZ ÜSTÜNE TURUNCU ÇİZGİ GRAFİK STİLLERİ
  imageChartCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 24,
    padding: 20,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#F3F4F6',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  chartHeaderRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 20,
  },
  chartMainValText: {
    fontSize: 24,
    fontWeight: '800',
    color: '#1C1917',
  },
  chartSubDateText: {
    fontSize: 12,
    color: '#78716C',
    marginTop: 2,
    fontWeight: '500',
  },
  chartDiffBadgeText: {
    fontSize: 14,
    fontWeight: '700',
    color: '#EA580C',
  },
  chartBodyWrapper: {
    height: 220,
    position: 'relative',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  yAxisOverlay: {
    position: 'absolute',
    top: 0,
    bottom: 24,
    left: 0,
    right: 0,
    justifyContent: 'space-between',
  },
  yGridRow: {
    flexDirection: 'row',
    alignItems: 'center',
    height: 1,
  },
  dashedLineItem: {
    flex: 1,
    height: 1,
    borderStyle: 'dashed',
    borderWidth: 0.5,
    borderColor: '#F3F4F6',
  },
  yGridLabelText: {
    fontSize: 11,
    color: '#A8A29E',
    width: 32,
    textAlign: 'right',
    marginLeft: 8,
    fontWeight: '500',
  },
  chartDataPointsArea: {
    position: 'absolute',
    top: 0,
    bottom: 24,
    left: 0,
    right: 40,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'stretch',
  },
  pointColumnItem: {
    flex: 1,
    alignItems: 'center',
    position: 'relative',
  },
  fluctuateDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#FFEDD5',
    position: 'absolute',
    borderWidth: 1,
    borderColor: '#FED7AA',
  },
  mainTrendDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: '#EA580C',
    position: 'absolute',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 4,
  },
  innerDotHole: {
    width: 4,
    height: 4,
    borderRadius: 2,
    backgroundColor: '#FFFFFF',
  },
  xAxisLabelsRow: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 40,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  xDateText: {
    fontSize: 10,
    color: '#A8A29E',
    fontWeight: '500',
  },
  timeFilterRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#FAFAFA',
    borderRadius: 20,
    padding: 4,
  },
  filterBtn: {
    paddingVertical: 6,
    paddingHorizontal: 10,
    borderRadius: 16,
  },
  filterBtnActive: {
    backgroundColor: '#000000',
  },
  filterBtnText: {
    fontSize: 11,
    fontWeight: '600',
    color: '#78716C',
  },
  filterBtnTextActive: {
    color: '#FFFFFF',
  },

  // VETERİNER KART STİLLERİ
  vetCardItem: {
    backgroundColor: '#FAF6F0',
    borderRadius: 14,
    padding: 12,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#E7E5E4',
  },
  vetTopDateBadge: {
    alignSelf: 'flex-start',
    backgroundColor: '#FEF3C7',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 6,
    marginBottom: 6,
    borderWidth: 1,
    borderColor: '#FDE68A',
  },
  vetDateText: {
    fontSize: 11,
    fontWeight: '800',
    color: '#C2410C',
  },
  vetClinicText: {
    fontSize: 14,
    fontWeight: '800',
    color: '#292524',
    marginBottom: 2,
  },
  vetDoctorText: {
    fontSize: 12,
    color: '#57534E',
    marginBottom: 8,
  },
  vetReasonBox: {
    backgroundColor: '#FFFFFF',
    padding: 8,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#F5F5F4',
  },
  vetReasonLabel: {
    fontSize: 10,
    fontWeight: '700',
    color: '#78716C',
    marginBottom: 2,
  },
  vetReasonText: {
    fontSize: 12,
    color: '#292524',
  },

  // GENEL BİLEŞEN VE DÜZEN STİLLERİ
  sectionHeaderTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#44403C',
    marginBottom: 12,
  },
  gridContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  gridCard: {
    width: '48%',
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    padding: 16,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#E7E5E4',
  },
  gridIcon: {
    fontSize: 42,
    marginBottom: 8,
  },
  gridCardImage: {
    width: 60,
    height: 60,
    borderRadius: 30,
    marginBottom: 8,
  },
  gridPetName: {
    fontSize: 16,
    fontWeight: '700',
    color: '#292524',
  },
  gridPetAge: {
    fontSize: 12,
    fontWeight: '600',
    color: '#EA580C',
    marginTop: 2,
  },
  gridPetBreed: {
    fontSize: 11,
    color: '#A8A29E',
    marginTop: 2,
  },
  addPetGridCard: {
    width: '48%',
    minHeight: 130,
    backgroundColor: '#FFEDD5',
    borderRadius: 20,
    padding: 16,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: '#EA580C',
    borderStyle: 'dashed',
  },
  addPetGridIcon: {
    fontSize: 32,
    fontWeight: '800',
    color: '#C2410C',
  },
  addPetGridText: {
    fontSize: 13,
    fontWeight: '700',
    color: '#C2410C',
  },

  card: {
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    padding: 18,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#E7E5E4',
  },
  cardTitle: {
    fontSize: 15,
    fontWeight: '700',
    color: '#292524',
    marginBottom: 12,
  },
  input: {
    backgroundColor: '#FAF6F0',
    borderRadius: 12,
    padding: 12,
    fontSize: 13,
    color: '#292524',
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#E7E5E4',
  },
  btnPrimary: {
    backgroundColor: '#EA580C',
    borderRadius: 12,
    paddingVertical: 12,
    alignItems: 'center',
    marginTop: 4,
    width: '100%',
  },
  btnPrimaryText: {
    color: '#FFFFFF',
    fontSize: 13,
    fontWeight: '700',
  },

  topNav: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 10,
  },
  btnBack: {
    paddingVertical: 6,
  },
  btnBackText: {
    color: '#EA580C',
    fontSize: 14,
    fontWeight: '700',
  },
  topNavTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#292524',
  },
  petHeaderCard: {
    backgroundColor: '#FFFFFF',
    marginHorizontal: 16,
    borderRadius: 16,
    padding: 14,
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#E7E5E4',
  },
  petHeaderAvatar: {
    fontSize: 36,
  },
  petHeaderAvatarImage: {
    width: 50,
    height: 50,
    borderRadius: 25,
  },
  petHeaderName: {
    fontSize: 18,
    fontWeight: '800',
    color: '#292524',
  },
  petHeaderSub: {
    fontSize: 12,
    color: '#78716C',
    marginTop: 2,
  },
  changePhotoHintText: {
    fontSize: 11,
    color: '#EA580C',
    fontWeight: '700',
    marginTop: 4,
  },

  tabBarContainer: {
    marginBottom: 14,
  },
  tabBarContent: {
    paddingHorizontal: 16,
    gap: 8,
  },
  tabItem: {
    backgroundColor: '#E7E5E4',
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 18,
  },
  tabItemActive: {
    backgroundColor: '#EA580C',
  },
  tabItemText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#57534E',
  },
  tabItemTextActive: {
    color: '#FFFFFF',
  },

  chipSelect: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 10,
    backgroundColor: '#FAF6F0',
    borderWidth: 1,
    borderColor: '#E7E5E4',
  },
  chipSelectActive: {
    backgroundColor: '#FFEDD5',
    borderColor: '#EA580C',
  },
  chipSelectText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#78716C',
  },
  chipSelectTextActive: {
    color: '#C2410C',
  },

  listItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#F5F5F4',
  },
  listItemTitle: {
    fontSize: 13,
    fontWeight: '700',
    color: '#292524',
  },
  listItemSub: {
    fontSize: 11,
    color: '#A8A29E',
    marginTop: 2,
  },
  priceText: {
    fontSize: 13,
    fontWeight: '700',
    color: '#059669',
  },
  emptyText: {
    fontSize: 12,
    color: '#A8A29E',
    fontStyle: 'italic',
  },

  bottomLogoutContainer: {
    paddingHorizontal: 16,
    paddingTop: 24,
    paddingBottom: 40,
    alignItems: 'center',
  },
  btnLogoutBottom: {
    backgroundColor: '#FEE2E2',
    paddingHorizontal: 28,
    paddingVertical: 12,
    borderRadius: 25,
    borderWidth: 1,
    borderColor: '#FCA5A5',
    width: '75%',
    alignItems: 'center',
  },
  btnLogoutBottomText: {
    color: '#DC2626',
    fontSize: 13,
    fontWeight: '700',
  },
});
